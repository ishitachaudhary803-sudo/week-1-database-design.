# Week 1: Database Design, Planning, and Modelling

## Project scenario
This project uses a hypothetical online bookstore. Customers place orders; each order contains one or more order items; each item refers to a book. Books are associated with an author and a category.

## Files
- `Week1_Database_Design_Report.docx` — detailed design report.
- `schema.sql` — MySQL-compatible table definitions with primary keys, foreign keys, constraints, and indexes.
- `er_diagram.png` — entity-relationship diagram.
- `README.md` — project overview and implementation notes.

## How to review
1. Open the Word report for assumptions, relationships, normalization, indexing, and performance considerations.
2. Review `er_diagram.png` for the logical relationships.
3. Open `schema.sql` in a text editor or MySQL-compatible SQL environment. The script creates the tables; it has not been executed against a live database.

## Important assumptions
The original task description did not specify a business scenario, so an online bookstore was selected as a clearly stated hypothetical example. `total_amount` is stored on an order for reporting convenience; in a production system it should be calculated or reconciled against order-item values by application logic or database procedures. Historical `unit_price` is stored on each order item so past orders remain accurate when a book's current price changes.

## Scope
This is a foundational logical design exercise, not a deployed application or production-tested database.
